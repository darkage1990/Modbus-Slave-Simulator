# Modbus RTU tests

There are not autotests. Just sketch executing Master and Slave on single ESP device and run Modbus calls with checking results.

## Required libraries
[StreamBuf](https://github.com/emelianov/StreamBuf)